#ifndef __SYSTEM_CLOCK_H
#define __SYSTEM_CLOCK_H

#ifdef __cplusplus
 extern "C" {
#endif 
  

extern void SystemClock_Config(void);


#ifdef __cplusplus
}
#endif

#endif
