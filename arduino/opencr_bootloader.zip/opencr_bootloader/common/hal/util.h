/*
 *  util.h
 *
 *  Created on: 2016. 5. 14.
 *      Author: Baram, PBHP
 */

#ifndef UTIL_H
#define UTIL_H


#ifdef __cplusplus
 extern "C" {
#endif


#include "def.h"
#include "bsp.h"





uint32_t millis();


#ifdef __cplusplus
}
#endif

#endif

