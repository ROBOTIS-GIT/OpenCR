opencr_ld
=======

OpenCR DownLoader for arduino and normal firmware


=======
Compile - Mac/Linux

make

=======
Compile - Windows

comming soon.


=======
Execute 

opencr_ld /dev/tty 115200 main.bin 1 




